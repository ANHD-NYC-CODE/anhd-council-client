import React from 'react'

const UserContext = React.createContext(undefined)

export default UserContext
