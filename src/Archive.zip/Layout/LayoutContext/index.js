import React from 'react'

const LayoutConfig = React.createContext(undefined)

export default LayoutConfig
