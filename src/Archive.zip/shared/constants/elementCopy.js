export const LOGIN_CTA = 'Request data access to view'
export const REQUEST_CTA = 'Request data access to view'