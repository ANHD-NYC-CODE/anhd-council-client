// PROPERTY

export const HOUSING_TYPE_RESIDENTIAL = 'all'
export const HOUSING_TYPE_RENT_STABILIZED = 'rs'
export const HOUSING_TYPE_SUBSIDIZED_HOUSING = 'rr'
export const HOUSING_TYPE_SMALL_HOME = 'sh'
export const HOUSING_TYPE_MARKET_RATE = 'mr'
export const HOUSING_TYPE_PUBLIC_HOUSING = 'ph'
