import React from 'react'

const ModalContext = React.createContext(undefined)

export default ModalContext
