import React from 'react'

const ConfigContext = React.createContext(undefined)

export default ConfigContext
